<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin</title>

<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>" />

</head>

<body>
	<div class="container-fluid">

        <div class="row header">
            <div class="col-lg-1">
                <img src="web/image/Logo1.png" class="img-responsive">
            </div>
            <div class="col-lg-9 judul">
                <h2>Peta Sebaran Covid - 19 | Provinsi Bali</h2>
            </div>

            <div class="row col-lg-2">
                <a class="admin" href="/home">LOG OUT</a>
            </div>
         </div>   <!--- End Header --->

    	<div class="row info">

        	<div class="col-lg-12">
                <div class="box">
                <h4>Input Data Kasus Covid - 19 di Bali</h4>

                    <form action="#" onsubmit="return check();" method="post" id="form">

                      <div class="form-group">
                        <label for="from" >Pilih Kabupaten :</label>
                        <select class="form-control">
                            <option value="Kab">Semua Kabupaten</option>
                            <option value="Dps">Denpasar</option>
                            <option value="Bdg">Badung</option>
                            <option value="Gnr">Gianyar</option>
                            <option value="Klk">Klungkung</option>
                            <option value="Krg">Karangasem</option>
                            <option value="Tbn">Tabanan</option>
                            <option value="Blg">Buleleng</option>
                            <option value="Bli">Bangli</option>
                            <option value="Jbr">Jembrana</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label for="from" >Tanggal :</label>
                        <input type="date" class="form-control" id="from">
                      </div>

                      <div class="form-group">
                        <label for="from" >Sembuh :</label>
                        <input type="number" class="form-control" id="from">
                      </div>

                      <div class="form-group">
                        <label for="from" >Dalam Perawatan :</label>
                        <input type="number" class="form-control" id="from">
                      </div>

                      <div class="form-group">
                        <label for="from" >Meninggal :</label>
                        <input type="number" class="form-control" id="from">
                      </div>

                       <button type="submit" class="btn btn-primary mb-2">Submit</button>

                    </form>
                </div><!--- End Box --->
             </div><!--- End Col-lg-12 --->

         	<div class="row text col-lg-12">
                <div class="col-lg-6">@Universitas  Udayana</div>
                <div class="col-lg-6 text-right">Peta Sebaran Covid - 19 Provinsi Bali 2020</div>
        	</div>

        </div><!--- End info --->
    </div><!--- End container --->

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Peta_Covid\resources\views/Admin/index.blade.php ENDPATH**/ ?>